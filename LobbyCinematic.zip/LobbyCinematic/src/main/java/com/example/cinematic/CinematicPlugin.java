package com.example.cinematic;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;
import java.util.UUID;
import java.util.stream.Collectors;

public class CinematicPlugin extends JavaPlugin implements Listener, TabExecutor {

    private final List<Location> points = new ArrayList<>();
    private final Map<UUID, Session> sessions = new HashMap<>();

    private boolean onlyFirstJoin;
    private boolean loop;
    private double secondsPerPoint;
    private int maxSeconds;
    private int joinDelay;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadSettings();
        getServer().getPluginManager().registerEvents(this, this);
        getCommand("cinematic").setExecutor(this);
        getCommand("cinematic").setTabCompleter(this);
    }

    @Override
    public void onDisable() {
        for (Session s : new ArrayList<>(sessions.values())) s.end(false);
    }

    // ---------------------------------------------------------------- config

    private void loadSettings() {
        reloadConfig();
        onlyFirstJoin = getConfig().getBoolean("only-first-join", true);
        joinDelay = getConfig().getInt("join-delay-ticks", 20);
        secondsPerPoint = Math.max(0.5, getConfig().getDouble("seconds-per-point", 4.0));
        loop = getConfig().getBoolean("loop", false);
        maxSeconds = getConfig().getInt("max-duration-seconds", 0);

        points.clear();
        for (String s : getConfig().getStringList("points")) {
            try {
                String[] a = s.split(",");
                World w = Bukkit.getWorld(a[0]);
                if (w == null || a.length < 6) continue;
                points.add(new Location(w,
                        Double.parseDouble(a[1]), Double.parseDouble(a[2]), Double.parseDouble(a[3]),
                        Float.parseFloat(a[4]), Float.parseFloat(a[5])));
            } catch (Exception ignored) {
                getLogger().warning("Titik tidak valid di config: " + s);
            }
        }
    }

    private void savePoints() {
        List<String> out = new ArrayList<>();
        for (Location l : points) {
            out.add(String.format(Locale.US, "%s,%.2f,%.2f,%.2f,%.2f,%.2f",
                    l.getWorld().getName(), l.getX(), l.getY(), l.getZ(), l.getYaw(), l.getPitch()));
        }
        getConfig().set("points", out);
        saveConfig();
    }

    // ---------------------------------------------------------------- events

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (p.hasPermission("cinematic.bypass")) return;
        if (onlyFirstJoin && p.hasPlayedBefore()) return;
        if (points.size() < 2) return;
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (p.isOnline()) start(p);
        }, joinDelay);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Session s = sessions.get(e.getPlayer().getUniqueId());
        if (s != null) s.end(false);
    }

    @EventHandler
    public void onSneak(PlayerToggleSneakEvent e) {
        if (!e.isSneaking()) return;
        Session s = sessions.get(e.getPlayer().getUniqueId());
        if (s != null) s.end(true);
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent e) {
        // cegah pemain pindah kamera lewat menu spectator / klik entitas
        if (e.getCause() == PlayerTeleportEvent.TeleportCause.SPECTATE
                && sessions.containsKey(e.getPlayer().getUniqueId())) {
            e.setCancelled(true);
        }
    }

    // ---------------------------------------------------------------- control

    private void start(Player p) {
        if (points.size() < 2 || sessions.containsKey(p.getUniqueId())) return;
        Session s = new Session(p, new ArrayList<>(points));
        sessions.put(p.getUniqueId(), s);
        s.begin();
    }

    private void stop(Player p) {
        Session s = sessions.get(p.getUniqueId());
        if (s != null) s.end(true);
    }

    // ---------------------------------------------------------------- session

    private class Session {
        final Player player;
        final List<Location> path;
        final GameMode prevMode;
        final Location prevLoc;
        final int segTicks;
        final int maxTicks;
        BukkitTask task;
        int tick = 0;

        Session(Player player, List<Location> path) {
            this.player = player;
            this.path = path;
            this.prevMode = player.getGameMode();
            this.prevLoc = player.getLocation().clone();
            this.segTicks = (int) Math.round(secondsPerPoint * 20);
            this.maxTicks = maxSeconds * 20;
        }

        void begin() {
            player.setGameMode(GameMode.SPECTATOR);
            player.teleport(path.get(0));
            task = Bukkit.getScheduler().runTaskTimer(CinematicPlugin.this, this::step, 1L, 1L);
        }

        void step() {
            if (!player.isOnline()) {
                end(false);
                return;
            }
            int n = path.size();
            int segs = loop ? n : n - 1;
            double pos = tick / (double) segTicks;

            if ((!loop && pos >= segs) || (maxTicks > 0 && tick >= maxTicks)) {
                end(true);
                return;
            }
            if (loop) pos = pos % segs;

            int i = (int) pos;
            double t = pos - i;

            Location p0 = path.get(idx(i - 1));
            Location p1 = path.get(idx(i));
            Location p2 = path.get(idx(i + 1));
            Location p3 = path.get(idx(i + 2));

            double x = cr(p0.getX(), p1.getX(), p2.getX(), p3.getX(), t);
            double y = cr(p0.getY(), p1.getY(), p2.getY(), p3.getY(), t);
            double z = cr(p0.getZ(), p1.getZ(), p2.getZ(), p3.getZ(), t);

            // yaw: ambil jalur putar terpendek relatif ke titik saat ini
            double base = p1.getYaw();
            double yaw = cr(base + wrap(p0.getYaw() - base), base,
                    base + wrap(p2.getYaw() - base), base + wrap(p3.getYaw() - base), t);
            double pitch = cr(p0.getPitch(), p1.getPitch(), p2.getPitch(), p3.getPitch(), t);
            pitch = Math.max(-90, Math.min(90, pitch));

            player.teleport(new Location(p1.getWorld(), x, y, z, (float) yaw, (float) pitch));

            if (tick % 20 == 0) {
                player.sendActionBar(Component.text("Tekan SHIFT untuk skip sinematik", NamedTextColor.YELLOW));
            }
            tick++;
        }

        int idx(int k) {
            int n = path.size();
            if (loop) return Math.floorMod(k, n);
            return Math.max(0, Math.min(n - 1, k));
        }

        void end(boolean notify) {
            if (task != null) task.cancel();
            sessions.remove(player.getUniqueId());
            player.setGameMode(prevMode);
            player.teleport(prevLoc);
            if (notify) {
                player.sendActionBar(Component.text("Selamat bermain!", NamedTextColor.GREEN));
            }
        }
    }

    // Catmull-Rom spline: gerakan mulus melewati semua titik
    private static double cr(double p0, double p1, double p2, double p3, double t) {
        return 0.5 * ((2 * p1)
                + (-p0 + p2) * t
                + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t * t
                + (-p0 + 3 * p1 - 3 * p2 + p3) * t * t * t);
    }

    private static double wrap(double deg) {
        deg = deg % 360;
        if (deg >= 180) deg -= 360;
        if (deg < -180) deg += 360;
        return deg;
    }

    // ---------------------------------------------------------------- commands

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("cinematic.admin")) {
            sender.sendMessage(Component.text("Kamu tidak punya izin.", NamedTextColor.RED));
            return true;
        }
        if (args.length == 0) {
            msg(sender, "/cinematic addpoint | clear | list | play [pemain] | stop [pemain] | reload");
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "addpoint" -> {
                if (!(sender instanceof Player p)) { msg(sender, "Hanya untuk pemain."); return true; }
                points.add(p.getLocation().clone());
                savePoints();
                msg(sender, "Titik #" + points.size() + " ditambahkan. Posisi & arah pandangan tersimpan.");
            }
            case "clear" -> {
                points.clear();
                savePoints();
                msg(sender, "Semua titik dihapus.");
            }
            case "list" -> {
                msg(sender, "Total titik: " + points.size());
                for (int i = 0; i < points.size(); i++) {
                    Location l = points.get(i);
                    msg(sender, String.format(Locale.US, "#%d  %s  %.1f %.1f %.1f", i + 1,
                            l.getWorld().getName(), l.getX(), l.getY(), l.getZ()));
                }
            }
            case "play" -> {
                Player target = args.length > 1 ? Bukkit.getPlayer(args[1])
                        : (sender instanceof Player p ? p : null);
                if (target == null) { msg(sender, "Pemain tidak ditemukan."); return true; }
                if (points.size() < 2) { msg(sender, "Minimal 2 titik dulu (/cinematic addpoint)."); return true; }
                start(target);
                msg(sender, "Memutar sinematik untuk " + target.getName());
            }
            case "stop" -> {
                Player target = args.length > 1 ? Bukkit.getPlayer(args[1])
                        : (sender instanceof Player p ? p : null);
                if (target == null) { msg(sender, "Pemain tidak ditemukan."); return true; }
                stop(target);
            }
            case "reload" -> {
                loadSettings();
                msg(sender, "Config dimuat ulang. Titik: " + points.size());
            }
            default -> msg(sender, "Subcommand tidak dikenal.");
        }
        return true;
    }

    private void msg(CommandSender s, String text) {
        s.sendMessage(Component.text("[Cinematic] ", NamedTextColor.AQUA)
                .append(Component.text(text, NamedTextColor.WHITE)));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length == 1) {
            return List.of("addpoint", "clear", "list", "play", "stop", "reload").stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        }
        return List.of();
    }
}
